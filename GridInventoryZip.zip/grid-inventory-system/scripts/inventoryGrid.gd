class_name InventoryGrid
extends GridContainer

var slotSize: int = 64; 
var slotBorderWidth: int = 2; 

@export var width: int = 3; 
@export var height: int = 3; 

var slotData: Array[InventorySlot] = []; 
var highlightedSlots: Array[InventorySlot] = [];

# avoid paths where you can, autoload
const GlobalEnums = preload("res://scripts/globalEnums.gd");

@export var slotPrefab: PackedScene; 

var spawnHandler : Node; 
var inputHandler : Node; 

var mouseHovering : bool = false; 
signal mouseEnteredGrid(grid: InventoryGrid);
signal mouseExitedGrid(grid: InventoryGrid);
signal mouseEnteredGridSlot(slot: InventorySlot);

func _ready() -> void:
	self.add_theme_constant_override("h_separation", 0);
	self.add_theme_constant_override("v_separation", 0);
	
func setFields(inputHandler: InventoryInputHandler, spawnHandler: InventoryItemSpawnHandler, slotSize: int):
	self.inputHandler = inputHandler; 
	self.spawnHandler = spawnHandler; 
	self.slotSize = slotSize;
	print("Slot size in grid: " + str(slotSize));
	setupInventory(); 
	
func _process(delta: float) -> void:
	
	if (get_global_rect().has_point((get_global_mouse_position()))):
		if mouseHovering == false: 
			mouseHovering = true; 
			emit_signal("mouseEnteredGrid", self);
	else:
		if mouseHovering == true:
			mouseHovering = false; 
			emit_signal("mouseExitedGrid", self);
	
# Setup inventory by filling the grid container with slots
func setupInventory(): 
	self.columns = width; 
	for y in height:
		for x in width:
			createSlot(); 

func createSlot(): 
	var inventorySlot = slotPrefab.instantiate();
	inventorySlot.rectSize = slotSize; 
	inventorySlot.borderWidth = slotBorderWidth; 
	
	inventorySlot.mouseEnteredSlot.connect(onSlotMouseEnter)
	inventorySlot.mouseExitedSlot.connect(onSlotMouseExit)
			
	add_child(inventorySlot);
	slotData.append(inventorySlot);
	#print(slotData);
	
func createEmptySlotData():
	var totalElements = width * height;  
	slotData = []; 
	slotData.resize(totalElements);
	
# Called whenever the mouse enters the area of a slot. 
func onSlotMouseEnter(slot: InventorySlot):
	emit_signal("mouseEnteredGridSlot", slot);

# Called whenever the mouse leaves the area of a slot
func onSlotMouseExit(slot: InventorySlot):
	pass;
	
#Gets the X and Y coords (representing column, and row)
#from a slot node
func getSlotCoords(slot: InventorySlot):
	var index = slotData.find(slot);
	if (index == -1):
		print("Slot not found.")
	else :
		var row = index / width
		var column = index % width

		return Vector2i(column, row);
	
#Gets a reference to an inventory slot using its row and column
func getSlotFromCoords(row: int, column: int):
	if (row < 0 || row >= height):
		return null; 
		
	if (column < 0 || column >= width):
		return null; 
		
	var index = getIndexFromCoords(row, column);
	
	if (index >= 0 && index < slotData.size()):
		return slotData[index];
		
	return null;

#Gets the index of an inventory slot using its row and column
func getIndexFromCoords(row: int, column: int):
	#print("Column (X): " + str(column) + " Row (Y): " + str(row))
	var index = row * width + column;  
	#print("Index: " + str(index))
	return index; 

#Attempts to place an item at a specified slot
#It will attempt to place an item using the top left-most
#tile in the item's structure. 
func placeItem(item: InventoryItem, anchorSlot: InventorySlot, fitSlots : Array[InventorySlot]):
	if (item.isSelected):
		item.isSelected = false; 
		
	for s in fitSlots: 
		s.addItem(item);
	if (anchorSlot != null):
		item.placeItem(anchorSlot);

func pickupItem(slot: InventorySlot):
	if (slot.containedItem != null):
		var currentHeldItem = slot.containedItem;
		currentHeldItem.pickUpItem(); 
		clearItemsTiles(currentHeldItem);
		return currentHeldItem; 
	else:
		print("Slot does not contain item");
		return null; 
		
func getSlotsWithItem(item: InventoryItem):
	var containSlots: Array[InventorySlot] = []; 
	
	for s in slotData: 
		if s.containedItem == item:
			containSlots.append(s);
	
	return containSlots; 
					
func clearItemsTiles(item : InventoryItem):
		for s in slotData: 
			if s.containedItem == item: 
				s.removeItem();
	
func swapItem(currentSlot: InventorySlot, currentHeldItem: InventoryItem):
	if (currentSlot.containedItem == null):
		print("Can't swap -- no item in slot");
		return null; 
	if (currentHeldItem == null):
		print("Can't swap without a held item")
		return null; 		
		
	var itemToPlace = currentHeldItem; 
	currentHeldItem = pickupItem(currentSlot);
	
	if (currentHeldItem == null):
		print("Couldn't pick up item.");
		return null; 
		
	var fitSpaces = getPotentialSpace(currentSlot, itemToPlace);
	if (checkForFit(itemToPlace.itemGrid, fitSpaces)):
		print("Item swapped.")
		placeItem(itemToPlace, currentSlot, fitSpaces);
		currentHeldItem.isSelected = true; 
		return currentHeldItem; 
	else: 
		print("New item does not fit.")
		attemptItemPlace(currentHeldItem.previousContainer, currentHeldItem);
		currentHeldItem = itemToPlace; 
		currentHeldItem.isSelected = true; 
		return currentHeldItem;
		
func dropItem(currentHeldItem : InventoryItem):
	var targetSlot = currentHeldItem.previousContainer; 
	var itemDropped = attemptItemPlace(targetSlot, currentHeldItem);
	return itemDropped; 

func attemptItemPlace(slot: InventorySlot, item: InventoryItem) -> bool:
	var fitSpaces = getPotentialSpace(slot, item);
	if (checkForFit(item.itemGrid, fitSpaces)):
		placeItem(item, slot, fitSpaces);
		return true; 
	else: 
		return false; 

#Gets the potential spaces on the grid that an item will occupy
func getPotentialSpace(slot: InventorySlot, item: InventoryItem):
	var itemShape = item.itemGrid; 
	var mouseCoord = getSlotCoords(slot)
	var startCoord = mouseCoord - item.anchor

	if startCoord == null:
		return [];
	#How many columns/how long along X item is
	var shapeWidth = itemShape[0].size();
	#How many rows/how long along Y item is
	var shapeHeight = itemShape.size(); 
	var slotList : Array[InventorySlot] = [];

	for y in range(startCoord.y, startCoord.y + shapeHeight):
		for x in range(startCoord.x, startCoord.x + shapeWidth):
			
			var itemTile = itemShape[y - startCoord.y][x - startCoord.x];
			if (itemTile != 1):
				continue;
				
			if (y >= height || y < 0):
				continue;
				
			if (x >= width || x < 0):
				continue;		
					
			var checkSlot = getSlotFromCoords(y, x);
			if (checkSlot != null):
				slotList.append(checkSlot);
	return slotList; 

#Gets the full rectangle (border box of space item will occupy) for rendering purposes
func getFullItemRect(slot: InventorySlot, item: InventoryItem):
	var itemShape = item.itemGrid; 
	var mouseCoord = getSlotCoords(slot)
	var startCoord = mouseCoord - item.anchor
	if startCoord == null:
		return [];
	#How many columns/how long along X item is
	var shapeWidth = itemShape[0].size();
	#How many rows/how long along Y item is
	var shapeHeight = itemShape.size(); 
	var slotList = [];
	
	for y in range(startCoord.y, startCoord.y + shapeHeight):
		for x in range(startCoord.x, startCoord.x + shapeWidth):
			
			if (y >= height || y < 0):
				continue;
				
			if (x >= width || x < 0):
				continue;		
					
			var checkSlot = getSlotFromCoords(y, x);
			if (checkSlot != null):
				slotList.append(checkSlot);
	return slotList;
	
# Checks if the shape is able to fit in the slots on the
# grid it would go into. Returns true if it can fit, false if not
func checkForFit(itemShape: Array, potentialSlots: Array[InventorySlot]):
	# If the itemshape and potentialslots exist/have content
	if (itemShape == null 
	|| itemShape.size() == 0 
	|| potentialSlots == null 
	|| potentialSlots.size() == 0) : 
		print("Item does not fit");
		return false; 
	else:		
		var itemShapeSum = 0; 
		
		for y in itemShape.size():
			for x in itemShape[y].size(): 
				if (itemShape[y][x] == 1):
					itemShapeSum += 1; 
		
		if (itemShapeSum != potentialSlots.size()):
			return false; 
			
		# Check if all of thse slots that the object
		# would go into are empty. If they are, return true.
		for slot in potentialSlots: 
			if slot.containedItem != null: 
				#print("Slot contains item");
				return false; 
		return true

#Returns highlighted slots to their original color
func unhighlightSlots(slots: Array[InventorySlot]): 
	for slot in slots: 
		slot.updateSlotColor(GlobalEnums.SlotState.DEFAULT) 
	
func highlightSlots(slots: Array[InventorySlot], slotState: GlobalEnums.SlotState):
	if slots == null || slots.size() <0:
		return; 
	for slot in slots: 
		slot.updateSlotColor(slotState);

#Highlights the appropriate slot based on the position of the mouse
#and the state of held items, etc.
func handleSlotHighlights(currentSlot: InventorySlot, currentHeldItem: InventoryItem):
	var mouseOnGrid = get_global_rect().has_point((get_global_mouse_position()));
	
	# all caps scares me
	if (mouseOnGrid): #IF MOUSE OVER INVENTORY
		if (currentHeldItem != null && currentSlot != null): #HELD ITEM: -> Hovering with item or going to rotate
			var newSlots = getPotentialSpace(currentSlot, currentHeldItem);
			
			if highlightedSlots != null && highlightedSlots.size() > 0:
				var resultsToUnhighlight = highlightedSlots.filter(
					func(slot): return not newSlots.has(slot))
				unhighlightSlots(resultsToUnhighlight);
				
			highlightedSlots = newSlots; 
			var highlightColor; 
			
			if (checkForFit(currentHeldItem.itemGrid, highlightedSlots)):
				highlightColor = GlobalEnums.SlotState.EMPTY;
			else:
				highlightColor = GlobalEnums.SlotState.TAKEN; 
				
			highlightSlots(highlightedSlots, highlightColor);	
			
		else : #NO HELD ITEM: -> Item is just hovering
			var newSlots : Array[InventorySlot];
			if (currentSlot.containedItem != null):
				newSlots = getSlotsWithItem(currentSlot.containedItem);
			else: 
				newSlots = [];
				newSlots.append(currentSlot);
			if highlightedSlots != null && highlightedSlots.size() > 0:
					#Check if highlighted slots exists
				var resultsToUnhighlight = highlightedSlots.filter(
					func(slot): return not newSlots.has(slot)
				)
				unhighlightSlots(resultsToUnhighlight);
			highlightedSlots = newSlots; 
			highlightSlots(highlightedSlots, GlobalEnums.SlotState.HOVERED);
	else : #IF MOUSE OFF INVENTORY
		#Unhighlight all slots.
		if (highlightedSlots.size() > 0 && highlightedSlots != null):
			unhighlightSlots(highlightedSlots);
		
